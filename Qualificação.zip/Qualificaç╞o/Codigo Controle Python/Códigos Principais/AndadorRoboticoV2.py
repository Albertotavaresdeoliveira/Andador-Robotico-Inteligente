##Alberto Tavares de Oliveira - 12/2024

import serial
import time
import numpy as np

#SERIAL_PORT = '/dev/ttyUSB0'  # Atualize para o dispositivo correto (use 'ls /dev/tty*' para verificar)
SERIAL_PORT = '/dev/ttyACM0'  # Atualize para o dispositivo correto (use 'ls /dev/tty*' para verificar)
#BAUD_RATE = 115200
BAUD_RATE = 31250

# Parâmetros do robô
L = 0.570  # Distância entre as rodas (em metros)
Re = 0.0775  # Raio da roda esquerda (em metros)
Rd = 0.0775  # Raio da roda direita (em metros)

# Vetor de estado inicial do robô (x, y, theta)
X = [0.0, 0.0, 0.0] # np.pi/2

#Start time
start_time = time.perf_counter()
#Intervalo de tempo
dt = 0.01

# Função para calcular a odometria (IMU)
def atualizar_odometria_V_W(v, w, dt, X):
    # Extrai o estado atual
    x, y, theta = X

    # Atualiza a pose do robô
    x += v * np.cos(theta + w * dt / 2.0) * dt
    y += v * np.sin(theta + w * dt / 2.0) * dt
    theta += w * dt

    # Normaliza theta entre -pi e pi
    theta = (theta + np.pi) % (2 * np.pi) - np.pi

    return [x, y, theta]

# Função para calcular a odometria (Encoderes)
def atualizar_odometria_WD_WE(wd, we, L, Re, Rd, dt, X):
    # Calcula o deslocamento linear e angular
    v = (-wd * Rd + we * Re) / 2.0
    w = (-wd * Rd - we * Re) / L

    #Odometria usando v e w
    X = atualizar_odometria_V_W(v, w, dt, X)
    
    return X

try:
    # Configurar a conexão serial
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.1)
    time.sleep(2)  # Aguardar estabilização da comunicação

    print(f"Comunicação serial Estabelecida com sucesso!")
    
    #velocidades angulares das rodas direita e esquerda em rad/s
    we = np.pi; wd = -np.pi
    #velocidades angulares das rodas direita e esquerda em RPM
    we = 10; wd = -10
    #velocidades linear e angular do andador
    v = 0.0; w = np.pi

    vel_esq = 2.4 #(RMP)
    vel_dir = 3.5 #(RPM)

    while True:
        # Enviar velocidades para o Arduino
        #data_to_send = f"{we:.2f} {wd:.2f}\\n"
        data_to_send = f"{we:.2f} {wd:.2f}\n"
        ser.write(data_to_send.encode('utf-8'))

        # Ler resposta do Arduino
        response = ser.readline().decode('utf-8').strip()
        print(f"Resposta obtida:")
        #print(response)
        if response:
            try:
                vel_esq, vel_dir = map(float, response.split())
                print(f"Velocidades recebidas: {vel_esq:.2f}, {vel_dir:.2f}")
            except ValueError:
                print("Erro ao interpretar a resposta recebida.")
                
        #Verificar o intervalo de tempo
        end_time = time.perf_counter()
        dt = float((end_time - start_time))
        #start_time = end_time #Atualiza o tempo inicial
        
        # Measure the execution time of a code block in milliseconds
        start_time = time.perf_counter()

        # Funções para atualizar a odometria
        #X = atualizar_odometria_WD_WE(wd, we, L, Re, Rd, dt, X) #Odometria por Encoder
        #X = atualizar_odometria_V_W(v, w, dt, X) #Odometria por IMU
        
        # Atualizar a odometria pelas medições
        X = atualizar_odometria_WD_WE(vel_dir, vel_esq, L, Re, Rd, dt, X) #Odometria por Encoder
        #X = atualizar_odometria_V_W(v, w, dt, X) #Odometria por IMU
        
        # Imprimir a posição e orientação
        print(f"Posição: x={X[0]:.2f} m, y={X[1]:.2f} m, theta={np.degrees(X[2]):.2f} graus")

        time.sleep(0.1)  # Aguardar 5ms para evitar sobrecarga

except serial.SerialException as e:
    print(f"Erro na comunicação serial: {e}")
except KeyboardInterrupt:
    print("Encerrando o programa...")
finally:
    if 'ser' in locals() and ser.is_open:
        ser.close()
