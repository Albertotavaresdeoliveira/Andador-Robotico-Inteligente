##Alberto Tavares de Oliveira - 12/2024

import Adafruit_BBIO.GPIO as GPIO
from Adafruit_BBIO.GPIO import setup, input, add_event_detect, RISING
import os
import sys
import serial
import numpy as np
import getopt, sys
import socket
import csv
import struct
import time

# import rcpy library
# This automatically initizalizes the robotics cape
import rcpy 
import rcpy.mpu9250 as mpu9250

print("SCRIPT")

BUTTON_PAUSE = "P8_9"; BUTTON_MODE = "P8_10"
LED_GREEN = "green"; LED_RED = "red"; LED0 = "USR0"; LED1 = "USR1"; LED2 = "USR2"; LED3 = "USR3"

#Setup inicial dos LED's
#GPIO.setup(LED_GREEN, GPIO.OUT); GPIO.setup(LED_RED, GPIO.OUT)
GPIO.setup(LED0, GPIO.OUT); GPIO.setup(LED1, GPIO.OUT); GPIO.setup(LED2, GPIO.OUT); GPIO.setup(LED3, GPIO.OUT)

#Setup inicial dos botões MODE e PAUSE
GPIO.setup(BUTTON_PAUSE, GPIO.IN); GPIO.setup(BUTTON_MODE, GPIO.IN)

SALVAR = False

################## SEQUENCIADOR DE LEDS ############################################################################
def SeqLeds(t):
    LEDs=4
    for i in range(LEDs): GPIO.setup("USR%d" % i, GPIO.OUT)
    for i in range(LEDs): GPIO.output("USR%d" % i, GPIO.HIGH); time.sleep(t)
    for i in range(LEDs): GPIO.output("USR%d" % i, GPIO.LOW); time.sleep(t)
    for i in range(LEDs): GPIO.output("USR%d" % i, GPIO.HIGH); time.sleep(t)
    for i in range(LEDs): GPIO.output("USR%d" % i, GPIO.LOW)
####################################################################################################################

SeqLeds(0.1)

'''
Configurado = False
state = False
#Configurando os comandos para ativar/desativar funcionalidades do código por meio dos botões MODE (true) e PAUSE (false)
while(not Configurado):
    OK = GPIO.input(BUTTON_MODE)
    if(GPIO.input(BUTTON_PAUSE)):
        state = not state
    #state = GPIO.input(BUTTON_PAUSE)
    GPIO.output(LED0, state)
    #GPIO.wait_for_edge(BUTTON_MODE, GPIO.BOTH)
    #print("Pressionado")
'''

# Comandos para ativar/desativar funcionalidades do código
AtivarSocket = False
AtivarIMU = False
AtivarEncoder = True #True
AtivarEnviarArduino = False
AtivarReceberArduino = True #True

if(AtivarIMU):
    rcpy.set_state(rcpy.RUNNING)
    mpu9250.initialize(
        mpu9250.ACCEL_FSR_2G,   # Acelerômetro: ±4 g
        #enable_dmp=True,
        enable_magnetometer = True) #True

########### BOTÃO PARA REINICIO DO CÓDIGO ##########################################################################
# Configuração do botão como GPIO de interrupção
#BUTTON_PIN = "P8_9"  # PAUSE=P8_9, MODE=P8_10
#GPIO.setup(BUTTON_PAUSE, GPIO.IN)

def restart_script(channel):
    print("Botão pressionado! Reiniciando o script...")
    os.execv(sys.executable, [sys.executable] + sys.argv)

# Adiciona interrupção no botão
add_event_detect(BUTTON_PAUSE, RISING, callback=restart_script)

########### BOTÃO PARA SALVAR DADOS DA ODOMETRIA ###################################################################
# Configuração do botão como GPIO de interrupção
def SalvarArquivo(channel):
    print("Salvando dados em arquivo")
    SeqLeds(0.1) #Pisca leds para indicar o processo de salvamento
    global SALVAR
    SALVAR = True

# Adiciona interrupção no botão
add_event_detect(BUTTON_MODE, RISING, callback=SalvarArquivo)

# Configuração do socket
HOST = '0.0.0.0'  # Aceita conexões de qualquer IP
#HOST = '192.168.1.99'  # IP da BeagleBone
PORT = 5000       # Porta do servidor

#################################### CRIAÇÃO DO SOCKET #############################################################
if(AtivarSocket):
    try:
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind((HOST, PORT))
        server_socket.listen(1) # (1)
        print(f"Servidor iniciado. Aguardando conexão na porta {PORT}...")
    except:
        print("Erro ao conectar, reiniciando o script...")
        os.execv(sys.executable, [sys.executable] + sys.argv) #Reinicia o script
    
    conn, addr = server_socket.accept()
    print(f"Conectado a {addr}")

#SERIAL_PORT = '/dev/ttyUSB0'  # Atualize para o dispositivo correto (use 'ls /dev/tty*' para verificar)
SERIAL_PORT = '/dev/ttyACM0'  # Atualize para o dispositivo correto (use 'ls /dev/tty*' para verificar)
#BAUD_RATE = 115200
BAUD_RATE = 31250

def save_integer_to_file(value, filepath="eeprom_data.bin"):
    with open(filepath, "wb") as f:
        f.write(struct.pack('<i', value))

def read_integer_from_file(filepath="eeprom_data.bin"):
    with open(filepath, "rb") as f:
        data = f.read(4)
    if len(data) != 4:
        raise ValueError("Dados incompletos no arquivo.")
    return struct.unpack('<i', data)[0]

def salvar_dados_em_arquivo(nome_arquivo, dados):
    """  Salva os dados de posição (x, y, theta) em um arquivo CSV."""
    with open(nome_arquivo, mode='w', newline='') as arquivo:
        escritor_csv = csv.writer(arquivo)
        escritor_csv.writerow(['x', 'y', 'theta'])  # Cabeçalho do arquivo
        escritor_csv.writerows(dados)
        
        # Garantir que os dados sejam enviados ao buffer
        arquivo.flush()
        # Sincronizar com o disco
        os.fsync(arquivo.fileno())

def ler_dados_e_plotar(nome_arquivo):
    x = []; y = []
    with open(nome_arquivo, mode='r') as arquivo:
        leitor_csv = csv.reader(arquivo)
        next(leitor_csv)  # Ignora o cabeçalho
        for linha in leitor_csv:
            x.append(float(linha[0]))
            y.append(float(linha[1]))

#Função que converte de RPM para rad/s
def RPMTORAD(RPM):
    #return RPM/(60*2*np.pi)
    return RPM * (2 * np.pi / 60)

#Função que converte de rad/s para RPM 
def RADTORPM(RAD):
    #return RPM/(60*2*np.pi)
    return RAD * (60 / (2 * np.pi))

def degrees_to_radians(deg):
    return np.radians(deg)

# Função para calcular a odometria (IMU)
def atualizar_odometria_V_W(v, w, dt, X):
    # Extrai o estado atual
    x, y, theta = X
    #Converte RPM para rad/s
    #w = RPMTORAD(w) #Comente esta linha se w já estiver em rad/s
    # Atualiza a pose do robô (w deve estar em rad/s)
    x += v * np.cos(theta + w * dt / 2.0) * dt
    y += v * np.sin(theta + w * dt / 2.0) * dt
    theta += w * dt
    # Normaliza theta entre -pi e pi
    theta = (theta + np.pi) % (2 * np.pi) - np.pi
    return [x, y, theta]

# Função para calcular a odometria (Encoderes)
def atualizar_odometria_WD_WE(wd, we, L, Re, Rd, dt, X):
    #Converte para rad/s
    wd = RPMTORAD(wd) #Comente esta linha se wd e we já estão em rad/s
    we = RPMTORAD(we) #Comente esta linha se wd e we já estão em rad/s
    # Calcula o deslocamento linear e angular
    v = (-wd * Rd + we * Re) / 2.0 #(wd e we devem estar em rad/s)
    w = (-wd * Rd - we * Re) / L #(wd e we devem estar em rad/s)
    #Odometria usando v e w
    X = atualizar_odometria_V_W(v, w, dt, X)
    return X

def calculate_velocity_linear(accel_x, dt):
    return accel_x * dt

def calculate_angular_velocity(gyr_z):
    rpm = (gyr_z * 60) / (2 * np.pi)
    return rpm
    
def integrador(integral, valor, dt):
    integral = integral + valor * dt
    return integral


'''
def remove_gravity(accel, roll, pitch):
    """Remove a influência da gravidade das leituras do acelerômetro."""
    ax, ay, az = accel
    # Componentes da gravidade nos eixos
    g_x = 9.81 * np.sin(pitch)
    g_y = 9.81 * np.sin(roll) * np.cos(pitch)
    g_z = 9.81 * np.cos(roll) * np.cos(pitch)
    # Subtrai as componentes da gravidade
    ax_corrected = ax - g_x
    ay_corrected = ay - g_y
    az_corrected = az - g_z
    return ax_corrected, ay_corrected, az_corrected

def calculate_roll_pitch(accel):
    """Calcula os ângulos de roll e pitch a partir do acelerômetro."""
    ax, ay, az = accel
    roll = np.arctan2(-ay, az)
    pitch = np.arctan2(ax, np.sqrt(ay**2 + az**2))
    return roll, pitch

#Calcula roll, pitch e yaw (com magnetômetro)
def calculate_orientation(accel, gyro, magnet, dt):
    # Desestrutura os dados
    ax, ay, az = accel
    gx, gy, gz = gyro
    mx, my, mz = magnet

    # Cálculo do roll e pitch usando acelerômetro
    roll = np.arctan2(-ay, az)
    pitch = np.arctan2(ax, np.sqrt(ay**2 + az**2))

    # Ajusta o magnetômetro com os ângulos de roll e pitch
    mx_comp = mx * np.cos(pitch) + mz * np.sin(pitch)
    my_comp = mx * np.sin(roll) * np.sin(pitch) + my * np.cos(roll) - mz * np.sin(roll) * np.cos(pitch)

    # Cálculo do yaw usando magnetômetro
    yaw = np.arctan2(my_comp, mx_comp)

    # Integração dos giroscópios (aplicação simplista)
    roll_gyro = roll + gx * dt
    pitch_gyro = pitch + gy * dt
    yaw_gyro = yaw + gz * dt

    return roll_gyro, pitch_gyro, yaw_gyro
'''


###### Teste de IMU ############################################
def calculate_orientation(accel):
    """
    Calcula os ângulos de inclinação (pitch e roll) com base no acelerômetro.
    """
    ax, ay, az = accel
    pitch = np.arctan2(-ax, np.sqrt(ay**2 + az**2))
    roll = np.arctan2(ay, az)
    return pitch, roll

def remove_gravity(accel, pitch, roll):
    """
    Remove a projeção da gravidade nas acelerações brutas.
    """
    ax, ay, az = accel
    g = 9.81  # Aceleração gravitacional em m/s²

    # Componentes da gravidade nos eixos
    g_x = g * np.sin(pitch)
    g_y = g * np.sin(roll) * np.cos(pitch)
    g_z = g * np.cos(pitch) * np.cos(roll)

    # Subtração da gravidade
    linear_accel = (
        ax - g_x,
        ay - g_y,
        az - g_z
    )
    return linear_accel

#Não movimente a placa durante a calibração
def calibrargiro(NumLeituras):
    GZ = np.zeros([NumLeituras,3])
    if rcpy.get_state() == rcpy.RUNNING:
        for i in range(NumLeituras):
            data = mpu9250.read()
            GZ[i] = data['gyro'] #Unidade bruta em graus/segundo
    global BiasGiroZ
    BiasGiroZ = -sum(GZ[:,2])/NumLeituras
    print(f"Bias giro zcal = {BiasGiroZ}")

def main():
    # Parâmetros do robô
    #L = 0.570  # Distância entre as rodas (em metros)
    #Re = 0.0775  # Raio da roda esquerda (em metros)
    #Rd = 0.0775  # Raio da roda direita (em metros)
    
    L = 0.555 + 0.005 # Distância entre as rodas (em metros) (+-0.005)
    Re = 0.0764 - 0.0007 # Raio da roda esquerda (em metros) (+- 0.0008 )
    Rd = 0.0764 - 0.0007 # Raio da roda direita (em metros) (+- 0.0008 )
    
    # Vetor de estado inicial do robô (x, y, theta)
    X = [0.0, 0.0, 0.0] # np.pi/2
    
    #Variaveis auxiliares da leitura da IMU
    NumLeituras = 10
    Leituras = np.zeros([NumLeituras,3])
    Gyro = np.zeros([NumLeituras,3])
    Accel = np.zeros([NumLeituras,3])
    Magnet = np.zeros([NumLeituras,3])
    
    #Variaveis para calibração de erro sistemático da IMU
    BiasAccX = -0.689
    #BiasAccY = -0.006312292
    BiasAccY = 0.0
    BiasGiroX = 0.0; BiasGiroY = 0.0; 
    global BiasGiroZ# = 0.910 #0.859
    BiasGiroZ = 0.910 #0.859
    
    print(f"Bias giro z = {BiasGiroZ}")
    
    calibrargiro(1000)
    
    print(f"Bias giro z2 = {BiasGiroZ}")
    
    #Acelerações reais nos eixos x, y e z a serem corrigidas
    Acc = np.zeros(3)
    
    #Inclinações para cálculo das acelerações ax, ay e az
    pitch = 0; roll = 0; yaw = 0
    #Start time
    start_time = time.perf_counter()
    #Intervalo de tempo
    dt = 0.01
    print("MAIN")
    try:
        # Configurar a conexão serial
        if(AtivarEnviarArduino or AtivarReceberArduino):
            ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.1) #Descomente para serial
            time.sleep(2)  # Aguardar estabilização da comunicação #Descomente para serial
            print(f"Comunicação serial Estabelecida com sucesso!")
        
        #velocidades angulares das rodas direita e esquerda em rad/s
        we = np.pi; wd = -np.pi
        #velocidades angulares das rodas direita e esquerda em RPM
        we = 20; wd = -20
        #velocidades linear e angular do andador
        v = 0.0; w = 0.0
    
        vel_esq = 0.0; vel_dir = 0.0 #(RPM)
        
        v_IMU = 0
        
        #Lista de Poses X preditas da odometria
        DADOS = []
    
        FIM = False
        
        t = 0
        t90 = 2.7225
        tl = 10.0
        
        ########### LOOP PRINCIPAL ##############################################################################################
        SeqLeds(0.3)
        start_time = time.perf_counter()
        while not FIM:
            # Enviar velocidades para o Arduino
            if(AtivarEnviarArduino):
                #data_to_send = f"{we:.2f} {wd:.2f}\\n"
                data_to_send = f"{we:.2f} {wd:.2f}\n" #Descomente para serial
                ser.write(data_to_send.encode('utf-8')) #Descomente para serial
    
            # Ler resposta do Arduino
            if(AtivarReceberArduino):
                response = ser.readline().decode('utf-8').strip()
                #print(f"Resposta obtida:")
                #print(response)
                if response:
                    try:
                        vel_esq, vel_dir = map(float, response.split())
                        #print(f"Velocidades recebidas: {vel_esq:.2f}, {vel_dir:.2f}")
                    except ValueError:
                        print("Erro ao interpretar a resposta recebida.")
            
            #print("Iniciando Leitura da IMU")
            #############  LEITURA DA IMU 2 #####################################################################################
            if(AtivarIMU):
                if rcpy.get_state() == rcpy.RUNNING:
                    for i in range(NumLeituras):
                        temp = mpu9250.read_imu_temp()
                        data = mpu9250.read()
                        Gyro[i] = data['gyro'] #Unidade bruta em graus/segundo
                        Accel[i] = data['accel'] #Unidade bruta em metros/segundo2
                        Magnet[i] = data['mag'] #Unidade bruta em uT
                    
                    #Calculo das médias dos valores lidos da IMU
                    ax = sum(Accel[:,0])/NumLeituras# + BiasAccX
                    ay = sum(Accel[:,1])/NumLeituras# + BiasAccY
                    az = sum(Accel[:,2])/NumLeituras# + BiasAccZ
                    wx = sum(Gyro[:,0])/NumLeituras# + BiasGiroX
                    wy = sum(Gyro[:,1])/NumLeituras# + BiasGiroY
                    wz = sum(Gyro[:,2])/NumLeituras + BiasGiroZ
                    mx = sum(Magnet[:,0])/NumLeituras# + BiasMagX
                    my = sum(Magnet[:,1])/NumLeituras# + BiasMagY
                    mz = sum(Magnet[:,2])/NumLeituras# + BiasMagZ   
                    
                    #Convertendo para rad/s
                    wx = degrees_to_radians(wx) #Converte graus/s em rad/s
                    wy = degrees_to_radians(wy) #Converte graus/s em rad/s
                    wz = degrees_to_radians(wz) #Converte graus/s em rad/s
                    
                    accel = [ax, ay, az]
                    gyro = [wx, wy, wz]
                    magnet = [mx, my, mz]
                    
                    pitch, roll = calculate_orientation(accel)  # Calcula a orientação
                    
                    #print(f"Roll: {roll}, Pitch{pitch}")
                    linear_accel = remove_gravity(accel, pitch, roll)  # Remove a gravidade (original)
                    #linear_accel = remove_gravity(accel, roll, pitch)  # Remove a gravidade (teste)
                    
                    #print(f"Aceleração linear: x={linear_accel[0]:.3f}, y={linear_accel[1]:.3f}, z={linear_accel[2]:.3f}")
                
                #wz = degrees_to_radians(wz) #Converte graus/s em rad/s
                laccy = linear_accel[1] + BiasAccY
                print(f"Acel linear_accel: {laccy}")
                #v_IMU = integrador(v_IMU, ax, dt)
                #v_IMU = integrador(v_IMU, linear_accel[1], dt) #Aceleração no eixo y da IMU
                v_IMU = integrador(v_IMU, laccy, dt) #Aceleração no eixo y da IMU
                
                #print(f"Vel v: {v_IMU}")
                #print(f"Vel wz: {wz}")
            
            '''
            #############  LEITURA DA IMU  #####################################################################################
            if(AtivarIMU):
                if rcpy.get_state() == rcpy.RUNNING:
                    for i in range(NumLeituras):
                        temp = mpu9250.read_imu_temp()
                        data = mpu9250.read()
                        Gyro[i] = data['gyro'] #Unidade bruta em graus/segundo
                        Accel[i] = data['accel'] #Unidade bruta em metros/segundo
                        Magnet[i] = data['mag'] #Unidade bruta em uT
                    #Calculo das médias dos valores lidos da IMU
                    ax = sum(Accel[:,0])/NumLeituras# + BiasAccX
                    ay = sum(Accel[:,1])/NumLeituras# +BiasAccY
                    az = sum(Accel[:,2])/NumLeituras# +BiasAccZ
                    wx = sum(Gyro[:,0])/NumLeituras# + BiasGiroX
                    wy = sum(Gyro[:,1])/NumLeituras# + BiasGiroY
                    wz = sum(Gyro[:,2])/NumLeituras #+ BiasGiroZ
                    mx = sum(Magnet[:,0])/NumLeituras# + BiasMagX
                    my = sum(Magnet[:,1])/NumLeituras# + BiasMagY
                    mz = sum(Magnet[:,2])/NumLeituras# + BiasMagZ
                    
                    #Convertendo para rad/s
                    wx = degrees_to_radians(wx) #Converte graus/s em rad/s
                    wy = degrees_to_radians(wy) #Converte graus/s em rad/s
                    wz = degrees_to_radians(wz) #Converte graus/s em rad/s
                    
                    accel = [ax, ay, az]
                    gyro = [wx, wy, wz]
                    magnet = [mx, my, mz]
                    
                    #print(f"Acel Accel: {accel}")
                    # Calcula os ângulos de roll e pitch
                    #roll, pitch = calculate_roll_pitch(accel)
                    # Calcula os ângulos de roll e pitch e yaw (com magnetômetro)
                    roll, pitch, yaw = calculate_orientation(accel, gyro, magnet, dt)
        
                    # Remove a gravidade das leituras
                    accel_corrected = remove_gravity(accel, roll, pitch)
                    #print(f"Accel corrected: {accel_corrected}")
                #v_IMU = integrador(v_IMU, ax, dt)
                #v_IMU = integrador(v_IMU, Acc[0][0], dt)
                #v_IMU = integrador(v_IMU, accel_corrected[0][0], dt)
                v_IMU = integrador(v_IMU, accel_corrected[1], dt) #Aceleração no eixo y da IMU
                #print(f"Acel ax: {ax}")
                print(f"Acel ay: {ay}")
                #print(f"Acel corrigida ax: {accel_corrected[0]}")
                print(f"Acel corrigida ay: {accel_corrected[1]}")
                #print(f"Acel Acc[0]: {Acc[0][0]}")
                #print(f"Vel v: {v_IMU}")
                #print(f"Vel wz: {wz}")
            ####################################################################################################################
            '''
        
            #Verificar o intrvalo de tempo
            end_time = time.perf_counter()
            #print(f"end_timer : {end_time}")
            dt = (end_time - start_time) #Fator de 10 para ajuste do tempo de integração ????
            #dt = 0.10159
            #dt = 0.1
            #print(f"dt : {dt}")
            start_time = end_time #Atualiza o tempo inicial
            
            
            # Imprimir a posição e orientação
            #print(f"Tempo t = {t:.2f}, Posição: x={X[0]:.2f} m, y={X[1]:.2f} m, theta={np.degrees(X[2]):.2f} graus")
            
            t += dt
            
            '''
            print(f"Tempo t = {t}" )
            if( t > 0  and t <= tl): #Reta
                we = 20; wd = -20
            if( t > tl and t <= tl+t90): #Curva
                we = -20; wd = -20
            if( t > tl+t90 and t <= 2*tl+t90): #Reta
                we = 20; wd = -20
            if( t > 2*tl+t90 and t <= 2*tl+2*t90): #Curva
                we = -20; wd = -20
            if( t > 2*tl+2*t90 and t <= 3*tl+2*t90): #Reta
                we = 20; wd = -20
            if( t > 3*tl+2*t90 and t <= 3*tl+3*t90): #Curva
                we = -20; wd = -20
            if( t > 3*tl+3*t90 and t <= 4*tl+3*t90): #Reta
                we = 20; wd = -20
            '''
                
            #############  ODOMETRIA  ##########################################################################################
            # Funções para atualizar a odometria
            #X = atualizar_odometria_WD_WE(wd, we, L, Re, Rd, dt, X) #Odometria por Encoder
            #X = atualizar_odometria_V_W(v, w, dt, X) #Odometria por IMU
            
            # Atualizar a odometria pelas medições
            if(AtivarEncoder):
                if(AtivarReceberArduino):
                    X = atualizar_odometria_WD_WE(vel_dir, vel_esq, L, Re, Rd, dt, X) #Odometria por Encoder com dados do arduino
                    DADOS.append(tuple(np.round(X, 3)))
                else:
                    X = atualizar_odometria_WD_WE(wd, we, L, Re, Rd, dt, X) #Odometria com velocidades fixas p/ teste
                    DADOS.append(tuple(np.round(X, 3)))
            elif (AtivarIMU):
                X = atualizar_odometria_V_W(v_IMU, wz, dt, X) #Odometria por IMU
                DADOS.append(tuple(np.round(X, 3)))
            ####################################################################################################################
            
            
            #############  ENVIO DE DADOS VIA SOCKET  ##########################################################################
            if(AtivarSocket):
                try:
                    # Envia os dados no formato "x,y\n"
                    #message = f"{x},{y}\n"
                    message = f"{X[0]},{X[1]}\n"
                    #message = f"{ax},{ay}\n"
                    conn.sendall(message.encode('utf-8'))
                except:
                    print("Erro no envio da mensagem via sockets")
            ####################################################################################################################
            
            #Se o botão (MODE) foi pressionado, salva em arquivo a sequencia de poses X do andador 
            if (SALVAR):
                SeqLeds(0.05)
                i = -1
                i = read_integer_from_file()
                print("SALVANDO DADOS...")
                if(AtivarIMU):
                    salvar_dados_em_arquivo('AndadorRobotico/DadosOdometria/IMU/SH/posicoesENC%d.csv' % i, DADOS)
                    #salvar_dados_em_arquivo('AndadorRobotico/DadosOdometria/IMU/SAH/posicoesENC%d.csv' % i, DADOS)
                    #salvar_dados_em_arquivo('AndadorRobotico/DadosOdometria/IMU/RETA/posicoesENC%d.csv' % i, DADOS)
                    #salvar_dados_em_arquivo('posicoesIMU%d.csv' % i, DADOS)
                    i = i + 1
                    save_integer_to_file(i)
                    time.sleep(3.0)
                else:
                    salvar_dados_em_arquivo('AndadorRobotico/DadosOdometria/Encoder/SH/posicoesENC%d.csv' % i, DADOS)
                    #salvar_dados_em_arquivo('AndadorRobotico/DadosOdometria/Encoder/SAH/posicoesENC%d.csv' % i, DADOS)
                    #salvar_dados_em_arquivo('AndadorRobotico/DadosOdometria/Encoder/RETA/posicoesENC%d.csv' % i, DADOS)
                    #salvar_dados_em_arquivo('posicoesENC%d.csv' % i, DADOS)
                    #salvar_dados_em_arquivo('/var/lib/cloud9/autorun/AndadorRobotico/DadosOdometria/Encoder/posicoesENC%d.csv' % i, DADOS)
                    #salvar_dados_em_arquivo('/cloud9/autorun/AndadorRobotico/DadosOdometria/Encoder/posicoesENC%d.csv' % i, DADOS)
                    #SeqLeds(0.05)
                    
                    i = i + 1
                    save_integer_to_file(i)
                    time.sleep(3.0)
                FIM = True
                    
            time.sleep(0.15)  # 0.1
    
    except serial.SerialException as e:
        print(f"Erro na comunicação serial: {e}")
    except KeyboardInterrupt:
        print("Encerrando o programa...")
    except (KeyboardInterrupt, BrokenPipeError):
        print("Encerrando servidor...")
    finally:
        print("Reiniciando Script...")
        if(AtivarSocket):
            conn.close()
            server_socket.close()
        #restart_script
        os.execv(sys.executable, [sys.executable] + sys.argv) #Reinicia o script
        #if 'ser' in locals() and ser.is_open:
        #    ser.close()

if __name__ == "__main__":
    main()