##Alberto Tavares de Oliveira - 12/2024

import serial
import time
import numpy as np

SERIAL_PORT = '/dev/ttyUSB0'  # Atualize para o dispositivo correto (use 'ls /dev/tty*' para verificar)
#BAUD_RATE = 115200
BAUD_RATE = 31250

# Parâmetros do robô
L = 0.570  # Distância entre as rodas (em metros)
R = 0.0775  # Raio das rodas (em metros)

# Vetor de estado inicial do robô (x, y, theta)
X = [0.0, 0.0, np.pi/2]

#Start time
start_time = time.perf_counter()
#Intervalo de tempo
dt = 0.01

# Função para calcular a odometria (IMU)
def atualizar_odometria_V_W(v, w, dt, X):
    # Extrai o estado atual
    x, y, theta = X

    # Atualiza a pose do robô
    x += v * np.cos(theta + w * dt / 2.0) * dt
    y += v * np.sin(theta + w * dt / 2.0) * dt
    theta += w * dt

    # Normaliza theta entre -pi e pi
    theta = (theta + np.pi) % (2 * np.pi) - np.pi

    return [x, y, theta]

# Função para calcular a odometria (Encoderes)
def atualizar_odometria_WD_WE(wd, we, L, R, dt, X):
    # Calcula o deslocamento linear e angular
    v = (wd * R + we * R) / 2.0
    w = (wd * R - we * R) / L

    #Odometria usando v e w
    X = atualizar_odometria_V_W(v, w, dt, X)
    
    return X

try:
    # Configurar a conexão serial
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.1)
    time.sleep(2)  # Aguardar estabilização da comunicação

    print(f"Comunicação serial Estabelecida com sucesso!")

    vel_esq = 1.0 #(RMP)
    vel_dir = -1.0 #(RPM)
    
    #velocidades angulares das rodas direita e esquerda em rad/s
    we = np.pi; wd = np.pi
    #velocidades linear e angular do andador
    v = 0.0; w = np.pi

    while True:
        # Enviar velocidades para o Arduino
        #data_to_send = f"{vel_esq:.2f} {vel_dir:.2f}\\n"
        data_to_send = f"{vel_esq:.2f} {vel_dir:.2f}\n"
        ser.write(data_to_send.encode('utf-8'))

        # Ler resposta do Arduino
        response = ser.readline().decode('utf-8').strip()
        print(f"Resposta obtida:")
        #print(response)
        if response:
            try:
                vel_esq, vel_dir = map(float, response.split())
                print(f"Velocidades recebidas: {vel_esq:.2f}, {vel_dir:.2f}")
            except ValueError:
                print("Erro ao interpretar a resposta recebida.")
                
        #Verificar o intervalo de tempo
        end_time = time.perf_counter()
        dt = float((end_time - start_time))
        #start_time = end_time #Atualiza o tempo inicial
        
        # Measure the execution time of a code block in milliseconds
        start_time = time.perf_counter()

        # Atualizar a odometria
        X = atualizar_odometria_WD_WE(wd, we, L, R, dt, X) #Odometria por Encoder
        #X = atualizar_odometria_V_W(v, w, dt, X) #Odometria por IMU
        
        # Imprimir a posição e orientação
        print(f"Posição: x={X[0]:.2f} m, y={X[1]:.2f} m, theta={np.degrees(X[2]):.2f} graus")

        time.sleep(0.1)  # Aguardar 5ms para evitar sobrecarga

except serial.SerialException as e:
    print(f"Erro na comunicação serial: {e}")
except KeyboardInterrupt:
    print("Encerrando o programa...")
finally:
    if 'ser' in locals() and ser.is_open:
        ser.close()
