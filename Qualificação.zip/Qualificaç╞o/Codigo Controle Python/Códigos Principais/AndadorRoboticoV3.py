##Alberto Tavares de Oliveira - 12/2024

import serial
import time
import numpy as np
import getopt, sys
import socket
import Adafruit_BBIO.GPIO as GPIO
from Adafruit_BBIO.GPIO import setup, input, add_event_detect, RISING
import os
import sys

# import rcpy library
# This automatically initizalizes the robotics cape
import rcpy 
import rcpy.mpu9250 as mpu9250

rcpy.set_state(rcpy.RUNNING)
mpu9250.initialize(enable_magnetometer = True) #True

########### BOTÃO PARA REINICIO DO CÓDIGO ##################
# Configuração do botão como GPIO de interrupção
BUTTON_PIN = "P8_9"  # PAUSE=P8_9, MODE=P8_10
GPIO.setup(BUTTON_PIN, GPIO.IN)

def restart_script(channel):
    print("Botão pressionado! Reiniciando o script...")
    os.execv(sys.executable, [sys.executable] + sys.argv)

# Adiciona interrupção no botão
add_event_detect(BUTTON_PIN, RISING, callback=restart_script)

################## SEQUENCIADOR DE LEDS ############################################################################
LEDs=4
for i in range(LEDs):
    GPIO.setup("USR%d" % i, GPIO.OUT)
for i in range(LEDs):
    GPIO.output("USR%d" % i, GPIO.HIGH)
    time.sleep(0.1)
for i in range(LEDs):
    GPIO.output("USR%d" % i, GPIO.LOW)
    time.sleep(0.1)
for i in range(LEDs):
    GPIO.output("USR%d" % i, GPIO.HIGH)
time.sleep(0.2)
for i in range(LEDs):
    GPIO.output("USR%d" % i, GPIO.LOW)
####################################################################################################################

# Configuração do socket
HOST = '0.0.0.0'  # Aceita conexões de qualquer IP
#HOST = '192.168.1.99'  # IP da BeagleBone
PORT = 5000       # Porta do servidor

# Criação do socket
try:
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen(1) # (1)
    print(f"Servidor iniciado. Aguardando conexão na porta {PORT}...")
except:
    print("Erro ao conectar, reiniciando o script...")
    os.execv(sys.executable, [sys.executable] + sys.argv) #Reinicia o script

conn, addr = server_socket.accept()
print(f"Conectado a {addr}")

#SERIAL_PORT = '/dev/ttyUSB0'  # Atualize para o dispositivo correto (use 'ls /dev/tty*' para verificar)
SERIAL_PORT = '/dev/ttyACM0'  # Atualize para o dispositivo correto (use 'ls /dev/tty*' para verificar)
#BAUD_RATE = 115200
BAUD_RATE = 31250

# Parâmetros do robô
L = 0.570  # Distância entre as rodas (em metros)
Re = 0.0775  # Raio da roda esquerda (em metros)
Rd = 0.0775  # Raio da roda direita (em metros)

# Vetor de estado inicial do robô (x, y, theta)
X = [0.0, 0.0, 0.0] # np.pi/2

#Start time
start_time = time.perf_counter()
#Intervalo de tempo
dt = 0.01

#Variaveis auxiliares da leitura da IMU
NumLeituras = 10
Leituras = np.zeros([NumLeituras,3])
Gyro = np.zeros([NumLeituras,3])
Accel = np.zeros([NumLeituras,3])
Magnet = np.zeros([NumLeituras,3])

#Variaveis para calibração de erro sistemátic da IMU
BiasAccX = -0.689
BiasGiroX = 0.0 
BiasGiroY = 0.0
BiasGiroZ = 0.0163

#Acelerações reais nos eixos x, y e z a serem corrigidas
Acc = np.zeros(3)

#Inclinações para cálculo das acelerações ax, ay e az
pitch = 0; roll = 0; yaw = 0

#Função que converte de RPM para rad/s
def RPMTORAD(RPM):
    return RPM/(60*2*np.pi)

def degrees_to_radians(deg):
    return np.radians(deg)

# Função para calcular a odometria (IMU)
def atualizar_odometria_V_W(v, w, dt, X):
    # Extrai o estado atual
    x, y, theta = X
    #Converte RPM para rad/s
    #w = RPMTORAD(w) #Comente esta linha se w já estiver em rad/s
    
    # Atualiza a pose do robô
    x += v * np.cos(theta + w * dt / 2.0) * dt
    y += v * np.sin(theta + w * dt / 2.0) * dt
    theta += w * dt

    # Normaliza theta entre -pi e pi
    theta = (theta + np.pi) % (2 * np.pi) - np.pi
    return [x, y, theta]

# Função para calcular a odometria (Encoderes)
def atualizar_odometria_WD_WE(wd, we, L, Re, Rd, dt, X):
    # Calcula o deslocamento linear e angular
    v = (-wd * Rd + we * Re) / 2.0
    w = (-wd * Rd - we * Re) / L

    #Odometria usando v e w
    X = atualizar_odometria_V_W(v, w, dt, X)
    return X

def calculate_velocity_linear(accel_x, dt):
    return accel_x * dt

def calculate_angular_velocity(gyr_z):
    rpm = (gyr_z * 60) / (2 * np.pi)
    return rpm
    
def integrador(integral, valor, dt):
    integral = integral + valor * dt
    return integral
    
def remove_gravity(accel, roll, pitch):
    """Remove a influência da gravidade das leituras do acelerômetro."""
    ax, ay, az = accel
    # Componentes da gravidade nos eixos
    g_x = -9.81 * np.sin(pitch)
    g_y = 9.81 * np.sin(roll) * np.cos(pitch)
    g_z = 9.81 * np.cos(roll) * np.cos(pitch)
    # Subtrai as componentes da gravidade
    ax_corrected = ax - g_x
    ay_corrected = ay - g_y
    az_corrected = az - g_z
    return ax_corrected, ay_corrected, az_corrected

def calculate_roll_pitch(accel):
    """Calcula os ângulos de roll e pitch a partir do acelerômetro."""
    ax, ay, az = accel
    roll = np.arctan2(-ay, az)
    pitch = np.arctan2(ax, np.sqrt(ay**2 + az**2))
    return roll, pitch

#Calcula roll, pitch e yaw (com magnetômetro)
def calculate_orientation(accel, gyro, magnet, dt):
    # Desestrutura os dados
    ax, ay, az = accel
    gx, gy, gz = gyro
    mx, my, mz = magnet

    # Cálculo do roll e pitch usando acelerômetro
    roll = np.arctan2(-ay, az)
    pitch = np.arctan2(ax, np.sqrt(ay**2 + az**2))

    # Ajusta o magnetômetro com os ângulos de roll e pitch
    mx_comp = mx * np.cos(pitch) + mz * np.sin(pitch)
    my_comp = mx * np.sin(roll) * np.sin(pitch) + my * np.cos(roll) - mz * np.sin(roll) * np.cos(pitch)

    # Cálculo do yaw usando magnetômetro
    yaw = np.arctan2(my_comp, mx_comp)

    # Integração dos giroscópios (aplicação simplista)
    roll_gyro = roll + gx * dt
    pitch_gyro = pitch + gy * dt
    yaw_gyro = yaw + gz * dt

    return roll_gyro, pitch_gyro, yaw_gyro

try:
    # Configurar a conexão serial
    #ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.1) #Descomente para serial
    #time.sleep(2)  # Aguardar estabilização da comunicação #Descomente para serial

    print(f"Comunicação serial Estabelecida com sucesso!")
    
    #velocidades angulares das rodas direita e esquerda em rad/s
    we = np.pi; wd = -np.pi
    #velocidades angulares das rodas direita e esquerda em RPM
    we = 10; wd = -10
    #velocidades linear e angular do andador
    v = 0.0; w = np.pi

    vel_esq = 10.0 #(RMP)
    vel_dir = -8.0 #(RPM)
    
    v_IMU = 0

    while True:
        print("Teste 1")
        # Enviar velocidades para o Arduino
        #data_to_send = f"{we:.2f} {wd:.2f}\\n"
        #data_to_send = f"{we:.2f} {wd:.2f}\n" #Descomente para serial
        #ser.write(data_to_send.encode('utf-8')) #Descomente para serial

        # Ler resposta do Arduino
        #response = ser.readline().decode('utf-8').strip()
        #print(f"Resposta obtida:")
        #print(response)
        #if response:
        #    try:
        #        vel_esq, vel_dir = map(float, response.split())
        #        print(f"Velocidades recebidas: {vel_esq:.2f}, {vel_dir:.2f}")
        #    except ValueError:
        #        print("Erro ao interpretar a resposta recebida.")
        
        #############  LEITURA DA IMU  #####################################################################################
        if rcpy.get_state() == rcpy.RUNNING:
            print("Teste 2")
            for i in range(NumLeituras):
                temp = mpu9250.read_imu_temp()
                data = mpu9250.read()
                Gyro[i] = data['gyro'] #Unidade bruta em graus/segundo
                Accel[i] = data['accel'] #Unidade bruta em metros/segundo
                Magnet[i] = data['mag'] #Unidade bruta em uT
            #Calculo das médias dos valores lidos da IMU
            ax = sum(Accel[:,0])/NumLeituras# + BiasAccX
            ay = sum(Accel[:,1])/NumLeituras# +BiasAccY
            az = sum(Accel[:,2])/NumLeituras# +BiasAccZ
            wx = sum(Gyro[:,0])/NumLeituras# + BiasGiroX
            wy = sum(Gyro[:,1])/NumLeituras# + BiasGiroY
            wz = sum(Gyro[:,2])/NumLeituras + BiasGiroZ
            mx = sum(Magnet[:,0])/NumLeituras# + BiasMagX
            my = sum(Magnet[:,1])/NumLeituras# + BiasMagY
            mz = sum(Magnet[:,2])/NumLeituras# + BiasMagZ
            
            print("Teste 3")
            #Convertendo para rad/s
            wx = degrees_to_radians(wx) #Converte graus/s em rad/s
            wy = degrees_to_radians(wy) #Converte graus/s em rad/s
            wz = degrees_to_radians(wz) #Converte graus/s em rad/s
            print("Teste 4")
            """
            #pitch = np.arctan2(ax, np.sqrt(ay**2+az**2))
            #roll = np.arctan2(ay, np.sqrt(ax**2+az**2))
            #yaw = np.arctan2(az, np.sqrt(ax**2+ay**2))
            
            R_x = np.array([ [1, 0, 0], [0, np.cos(roll), -np.sin(roll)], [0, np.sin(roll), np.cos(roll)] ])
            R_y = np.array([ [np.cos(pitch), 0, np.sin(pitch)], [0, 1, 0], [-np.sin(pitch), 0, np.cos(pitch)] ])
            R_z = np.array([ [np.cos(yaw), -np.sin(yaw), 0], [np.sin(yaw), np.cos(yaw), 0], [0, 0, 1] ])
            
            Rot = R_z @ R_y @ R_x  # Multiplicação na ordem ZYX
            
            #Matriz de rotação para correção das acelerações
            #Rot = np.array([[np.cos(roll),np.sin(pitch)*np.sin(roll),-np.cos(pitch)*np.sin(roll) ]
            #,[0,np.cos(pitch),np.sin(pitch)]
            #,[np.sin(roll),-np.sin(pitch)*np.cos(roll),np.cos(pitch)*np.cos(roll)]])
            
            #Aceleração dos eixos x, y e z lidas da IMU (com influencia da gravidade)
            AccIMU = np.array([[ax], [ay], [az]])
            
            #Acelerações corrigidas
            Acc = Rot @ AccIMU
            """
            
            accel = [ax, ay, az]
            gyro = [wx, wy, wz]
            magnet = [mx, my, mz]
            
            print("Teste 5")
            #print(f"Acel Accel: {accel}")
            # Calcula os ângulos de roll e pitch
            #roll, pitch = calculate_roll_pitch(accel)
            # Calcula os ângulos de roll e pitch e yaw (com magnetômetro)
            roll, pitch, yaw = calculate_orientation(accel, gyro, magnet, dt)

            print("Teste 6")
            # Remove a gravidade das leituras
            accel_corrected = remove_gravity(accel, roll, pitch)
            #print(f"Accel corrected: {accel_corrected}")
            print("Teste 7")
        #v_IMU = integrador(v_IMU, ax, dt)
        #v_IMU = integrador(v_IMU, Acc[0][0], dt)
        #v_IMU = integrador(v_IMU, accel_corrected[0][0], dt)
        v_IMU = integrador(v_IMU, accel_corrected[0], dt)
        print("Teste 8")
        #print(f"Acel corrigida ax: {accel_corrected[0]}")
        #print(f"Acel Acc[0]: {Acc[0][0]}")
        #print(f"Vel v: {v_IMU}")
        #print(f"Vel wz: {wz}")
        ####################################################################################################################
        #Verificar o intervalo de tempo
        end_time = time.perf_counter()
        dt = float((end_time - start_time))
        start_time = end_time #Atualiza o tempo inicial
        # Measure the execution time of a code block in milliseconds
        #start_time = time.perf_counter()

        #############  ODOMETRIA  ##########################################################################################
        # Funções para atualizar a odometria
        #X = atualizar_odometria_WD_WE(wd, we, L, Re, Rd, dt, X) #Odometria por Encoder
        #X = atualizar_odometria_V_W(v, w, dt, X) #Odometria por IMU
        
        # Atualizar a odometria pelas medições
        #X = atualizar_odometria_WD_WE(vel_dir, vel_esq, L, Re, Rd, dt, X) #Odometria por Encoder
        X = atualizar_odometria_V_W(v_IMU, wz, dt, X) #Odometria por IMU
        ####################################################################################################################
        # Imprimir a posição e orientação
        print(f"Posição: x={X[0]:.2f} m, y={X[1]:.2f} m, theta={np.degrees(X[2]):.2f} graus")
        try:
            #############  ENVIO DE DADOS VIA SOCKET  ##########################################################################
            # Envia os dados no formato "x,y\n"
            #message = f"{x},{y}\n"
            message = f"{X[0]},{X[1]}\n"
            #message = f"{ax},{ay}\n"
            conn.sendall(message.encode('utf-8'))
            ####################################################################################################################
        except:
            print("Erro no envio da mensagem via sockets")
        time.sleep(0.2)  # Aguardar 5ms para evitar sobrecarga

except serial.SerialException as e:
    print(f"Erro na comunicação serial: {e}")
except KeyboardInterrupt:
    print("Encerrando o programa...")
except (KeyboardInterrupt, BrokenPipeError):
    print("Encerrando servidor...")
finally:
    print("Fechando sockets...")
    conn.close()
    server_socket.close()
    os.execv(sys.executable, [sys.executable] + sys.argv) #Reinicia o script
    #if 'ser' in locals() and ser.is_open:
    #    ser.close()
    
