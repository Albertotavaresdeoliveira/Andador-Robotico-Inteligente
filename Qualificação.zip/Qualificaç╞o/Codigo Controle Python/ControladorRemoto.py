import socket

#UDP_IP = "10.7.220.102"  # IP da BeagleBone Blue (LARS)
UDP_IP = "192.168.1.99"  # IP da BeagleBone Blue (Casa)
UDP_PORT = 5005           # Porta configurada no servidor

# Criação do socket UDP
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Função para enviar comandos
def send_command(command):
    client_socket.sendto(command.encode("utf-8"), (UDP_IP, UDP_PORT))

# Exemplos de uso
send_command("LED_GREEN_ON")   # Acender LED verde
send_command("LED_GREEN_OFF")  # Apagar LED verde
send_command("LED_BLUE_ON")    # Acender LED azul
send_command("LED_BLUE_OFF")   # Apagar LED azul
send_command("LED_RED_ON")     # Acender LED vermelho
send_command("LED_RED_OFF")    # Apagar LED vermelho
#send_command("EXIT")           # Encerra o servidor

print("FIM")
