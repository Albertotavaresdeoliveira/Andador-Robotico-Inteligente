import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
import glob

def ler_dados_csv(file_path):
    """
    Lê um arquivo CSV contendo as posições e retorna os dados como um DataFrame.

    Parâmetros:
        file_path (str): Caminho para o arquivo CSV.

    Retorna:
        pandas.DataFrame: Dados do arquivo CSV.
    """
    return pd.read_csv(file_path)

def criar_grafico(nomevariavel, Posfinal):
    """
    Cria um gráfico vazio e retorna o objeto Axes.

    Retorna:
        matplotlib.axes.Axes: Objeto Axes do gráfico.
    """
    fig, ax = plt.subplots(figsize=(7, 7))
    plt.axis('equal')
    ax.set_xlabel("X(m)", fontsize=14)
    ax.set_ylabel("Y(m)", fontsize=14)
    #ax.set_title("Calibração de odometria - Sentido Anti-Horário")
    #ax.set_title("Dispersão das posições finais - Sentido Anti-Horário")
    #ax.set_title("Calibração de odometria - Sentido Horário")
    #ax.set_title("Dispersão das posições finais - Sentido Horário")
    #ax.set_title("Calibração de odometria - Trajeto Retilíneo")
    #ax.set_title("Dispersão das posições finais - Trajeto Retilíneo")
    
    #ax.set_title("Calibração de odometria - " + nomevariavel)
    ax.set_title("Dispersão das posições finais - " + nomevariavel)

    if nomevariavel == "Sentido Anti-Horário":
        ax.scatter(0, 0, color='black', marker='x', label="Marcadores", zorder=6)
        ax.scatter(0, 1.6, color='black', marker='x', label="Marcadores", zorder=6)
        ax.scatter(1.6, 0, color='black', marker='x', label="Marcadores", zorder=6)
        ax.scatter(1.6, 1.6, color='black', marker='x', label="Marcadores", zorder=6)
    
    if nomevariavel == "Sentido Horário":
        ax.scatter(0, 0, color='black', marker='x', label="Marcadores", zorder=6)
        ax.scatter(0, -1.6, color='black', marker='x', label="Marcadores", zorder=6)
        ax.scatter(1.6, 0, color='black', marker='x', label="Marcadores", zorder=6)
        ax.scatter(1.6, -1.6, color='black', marker='x', label="Marcadores", zorder=6)

    if nomevariavel == "Trajeto Retilíneo":
        ax.scatter(Posfinal[0], Posfinal[1], color='black', marker='x', linewidth=3, label="Marcadores", zorder=6)

    
    ax.axhline(0, color='black', linewidth=0.5)
    ax.axvline(0, color='black', linewidth=0.5)
    ax.grid(color='gray', linestyle='--', linewidth=0.5)
    ax.tick_params(axis='both', which='major', labelsize=10)  # Ajustar o tamanho da fonte dos valores dos eixos
    return ax

def adicionar_caminho_ao_grafico(ax, dados, label):
    """
    Adiciona o caminho percorrido ao gráfico.

    Parâmetros:
        ax (matplotlib.axes.Axes): O objeto Axes onde os dados serão adicionados.
        dados (pandas.DataFrame): DataFrame contendo as colunas 'x' e 'y'.
        label (str): Rótulo para o caminho no gráfico.
    """
    ax.plot(dados['x'], dados['y'], linestyle="-", linewidth=1, label=label)

def adicionar_dados_finais(ax, dados_finais):
    """
    Adiciona as posições finais como pontos ao gráfico.

    Parâmetros:
        ax (matplotlib.axes.Axes): O objeto Axes onde os dados serão adicionados.
        dados_finais (pandas.DataFrame): DataFrame contendo as colunas 'x' e 'y' das posições finais.
    """
    ax.scatter(dados_finais['x'], dados_finais['y'], color='blue', label="Posições Finais", zorder=5)

def adicionar_elipse_e_reta(ax, dados_finais, Posfinal):
    """
    Adiciona ao gráfico a elipse de dispersão das posições finais e a reta até o centróide.

    Parâmetros:
        ax (matplotlib.axes.Axes): O objeto Axes onde a elipse e a reta serão adicionadas.
        dados_finais (pandas.DataFrame): DataFrame contendo as colunas 'x' e 'y' das posições finais.
    """
    # Cálculo do centróide
    centroide = dados_finais.mean()

    # Cálculo da matriz de covariância
    cov_matrix = np.cov(dados_finais['x'], dados_finais['y'])

    print("Matriz Covariância:", cov_matrix)

    # Cálculo dos autovalores e autovetores
    eigvals, eigvecs = np.linalg.eigh(cov_matrix)

    # Ordenação dos autovalores e autovetores
    order = np.argsort(eigvals)[::-1]
    eigvals = eigvals[order]
    eigvecs = eigvecs[:, order]

    # Parâmetros da elipse
    angle = np.degrees(np.arctan2(eigvecs[1, 0], eigvecs[0, 0]))
    width, height = 2 * np.sqrt(eigvals * 2)

    # Adição da elipse
    elipse = Ellipse(
        xy=centroide, width=width, height=height, angle=angle,
        edgecolor='red', facecolor='none', linewidth=2, label="Elipse de dispersão"
    )
    ax.add_patch(elipse)

    # Adição do centróide
    ax.scatter(centroide['x'], centroide['y'], color='red', label="Centróide", zorder=6)

    # Adição da reta
    ax.plot([Posfinal[0], centroide['x']], [Posfinal[1], centroide['y']], color="green", linestyle="--", linewidth=3, label="Reta até o centróide")

    # Imprimir informações no terminal
    #distancia_centroide_origem = np.sqrt(centroide['x']**2 + centroide['y']**2)
    distancia_centroide_origem = np.sqrt((centroide['x'] - Posfinal[0])**2 + (centroide['y'] - Posfinal[1])**2)
    
    print(f"Coordenadas do centróide: x = {centroide['x']:.3f}, y = {centroide['y']:.3f}")
    print(f"Comprimento da reta até o centróide: {distancia_centroide_origem:.3f}")

def main():
    """
    Função principal para processar múltiplos arquivos CSV, plotar caminhos e calcular a elipse de dispersão.
    """

    #AntesDacalibracao
    #path_pattern = "Anti-Horário/posicoesENC*.csv"; Posfinal = [0, 0]; nomevariavel = "Sentido Anti-Horário"
    #path_pattern = "Horário/posicoesENC*.csv"; Posfinal = [0, 0]; nomevariavel = "Sentido Horário"
    #path_pattern = "Reta/posicoesENC*.csv"; Posfinal = [6.4, 0]; nomevariavel = "Trajeto Retilíneo"

    #Aposcalibracao
    #path_pattern = "Anti-HorárioCalibrada/posicoesENC*.csv"; Posfinal = [0, 0]; nomevariavel = "Sentido Anti-Horário"
    path_pattern = "HorárioCalibrada/posicoesENC*.csv"; Posfinal = [0, 0]; nomevariavel = "Sentido Horário"
    #path_pattern = "RetaCalibrada/posicoesENC*.csv"; Posfinal = [6.4, 0]; nomevariavel = "Trajeto Retilíneo"
    #path_pattern = "RetaCalibrada2/posicoesENC*.csv"; Posfinal = [6.4, 0]; nomevariavel = "Trajeto Retilíneo"


    arquivos = glob.glob(path_pattern)

    grafico = criar_grafico(nomevariavel, Posfinal)

    todas_posicoes_finais = []

    for arquivo in arquivos:
        dados = ler_dados_csv(arquivo)

        # Adicionar o caminho completo ao gráfico
        adicionar_caminho_ao_grafico(grafico, dados, label=f"Caminho de {arquivo}")

        # Coletar as posições finais
        todas_posicoes_finais.append(dados.iloc[-1])

    # Consolidar todas as posições finais
    todas_posicoes_finais = pd.DataFrame(todas_posicoes_finais)

    # Adicionar posições finais como pontos
    adicionar_dados_finais(grafico, todas_posicoes_finais)

    # Adicionar elipse de dispersão e reta até o centróide
    adicionar_elipse_e_reta(grafico, todas_posicoes_finais, Posfinal)

    #plt.legend()
    plt.show()

if __name__ == "__main__":
    main()
