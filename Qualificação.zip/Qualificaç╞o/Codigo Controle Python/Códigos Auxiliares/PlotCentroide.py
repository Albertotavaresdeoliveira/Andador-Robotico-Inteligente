import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse

# Geração de dados fictícios de exemplo (10 medidas de posições finais)
posicoes = np.array([
    [1.2, 0.8],
    [1.5, 1.1],
    [1.3, 1.0],
    [1.4, 0.9],
    [1.6, 1.2],
    [1.7, 1.3],
    [1.8, 1.1],
    [1.5, 1.0],
    [1.4, 0.8],
    [1.6, 1.1]
])

# Cálculo do centróide
centroide = np.mean(posicoes, axis=0)

# Cálculo da matriz de covariância
cov_matrix = np.cov(posicoes.T)

# Cálculo dos autovalores e autovetores da matriz de covariância
eigvals, eigvecs = np.linalg.eigh(cov_matrix)

# Ordenação dos autovalores e autovetores
order = np.argsort(eigvals)[::-1]
eigvals = eigvals[order]
eigvecs = eigvecs[:, order]

# Ângulo de rotação da elipse (em graus)
angle = np.degrees(np.arctan2(eigvecs[1, 0], eigvecs[0, 0]))

# Comprimentos dos semi-eixos da elipse (2 sigmas para cobertura de ~95%)
width, height = 2 * np.sqrt(eigvals * 2)

# Plot das posições, do centróide, da elipse e da reta de erro
fig, ax = plt.subplots()

# Plot das medidas
ax.scatter(posicoes[:, 0], posicoes[:, 1], label="Medições", color="blue", s=50)

# Plot do centróide
ax.scatter(centroide[0], centroide[1], label="Centróide", color="red", s=100)

# Adição da elipse de dispersão
elipse = Ellipse(xy=centroide, width=width, height=height, angle=angle, edgecolor='green', facecolor='none', linewidth=2, label="Elipse de dispersão")
ax.add_patch(elipse)

# Adição da reta de erro
ax.plot([0, centroide[0]], [0, centroide[1]], color="orange", linestyle="--", linewidth=2, label="Reta de erro")

# Configurações do gráfico
ax.axhline(0, color='black',linewidth=0.5)
ax.axvline(0, color='black',linewidth=0.5)
ax.grid(color = 'gray', linestyle = '--', linewidth = 0.5)
ax.set_aspect('equal', adjustable='datalim')
plt.xlabel("X")
plt.ylabel("Y")
plt.title("Dispersão das Medidas de Odometrias")
plt.legend()
plt.show()
