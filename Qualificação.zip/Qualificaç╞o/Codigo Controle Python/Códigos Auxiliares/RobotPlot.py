import serial
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import numpy as np

# Configurações da porta serial
SERIAL_PORT = 'COM5'  # Substitua pelo nome da porta serial correta
BAUD_RATE = 31250      # Taxa de transmissão (deve corresponder à configuração do dispositivo)

# Inicialização da conexão serial
try:
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
    print(f"Conectado à porta {SERIAL_PORT} com baud rate {BAUD_RATE}.")
except serial.SerialException as e:
    print(f"Erro ao abrir a porta serial: {e}")
    exit()

# Listas para armazenar as posições recebidas
x_data = []
y_data = []

def update(frame):
    global x_data, y_data
    # Lê os dados da porta serial
    try:
        if ser.in_waiting > 0:
            #line = ser.readline().decode('utf-8').strip()
            #line = ser.readline().decode('utf-8', errors='replace').strip()
            line = ser.readline().decode('utf-8', errors='ignore').strip()
            if line:
                try:
                    x, y, theta = map(float, line.split(','))
                    x_data.append(x)
                    y_data.append(y)

                    # Atualiza o gráfico
                    ax.clear()
                    ax.plot(x_data, y_data, label='Trajetória do robô')
                    ax.set_xlabel('Posição X (m)')
                    ax.set_ylabel('Posição Y (m)')
                    ax.set_title('Posição do Robô em Tempo Real')
                    ax.legend()
                except ValueError:
                    print(f"Dados inválidos recebidos: {line}")
    except serial.SerialException as e:
        print(f"Erro de comunicação serial: {e}")

# Configuração do gráfico
fig, ax = plt.subplots()
ani = FuncAnimation(fig, update, interval=100)  # Atualização a cada 100ms

# Exibe o gráfico
try:
    plt.show()
except KeyboardInterrupt:
    print("Encerrando...")
finally:
    ser.close()
    print("Conexão serial encerrada.")
