import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
import pandas as pd
import glob
import numpy as np

def PlotElipse(posicoes, fig, ax):
    # Cálculo do centróide
    centroide = np.mean(posicoes, axis=0)

    # Cálculo da matriz de covariância
    cov_matrix = np.cov(posicoes.T)

    # Cálculo dos autovalores e autovetores da matriz de covariância
    eigvals, eigvecs = np.linalg.eigh(cov_matrix)

    # Ordenação dos autovalores e autovetores
    order = np.argsort(eigvals)[::-1]
    eigvals = eigvals[order]
    eigvecs = eigvecs[:, order]

    # Ângulo de rotação da elipse (em graus)
    angle = np.degrees(np.arctan2(eigvecs[1, 0], eigvecs[0, 0]))

    # Comprimentos dos semi-eixos da elipse (2 sigmas para cobertura de ~95%)
    width, height = 2 * np.sqrt(eigvals * 2)

    # Plot das posições, do centróide, da elipse e da reta de erro
    #fig, ax = plt.subplots()

    # Plot das medidas
    ax.scatter(posicoes[:, 0], posicoes[:, 1], label="Medições", color="blue", s=50)

    # Plot do centróide
    ax.scatter(centroide[0], centroide[1], label="Centróide", color="red", s=100)

    # Adição da elipse de dispersão
    elipse = Ellipse(xy=centroide, width=width, height=height, angle=angle, edgecolor='green', facecolor='none', linewidth=2, label="Elipse de dispersão")
    ax.add_patch(elipse)

    # Adição da reta de erro
    ax.plot([0, centroide[0]], [0, centroide[1]], color="orange", linestyle="--", linewidth=2, label="Reta de erro")

    # Configurações do gráfico
    ax.axhline(0, color='black',linewidth=0.5)
    ax.axvline(0, color='black',linewidth=0.5)
    ax.grid(color = 'gray', linestyle = '--', linewidth = 0.5)
    ax.set_aspect('equal', adjustable='datalim')
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.title("Dispersão das Medidas de Odometrias")
    plt.legend()
    plt.show()

def plot_individual_csv(file_path):
    """
    Lê um arquivo CSV com dados de posição (x, y) e plota o gráfico.

    Args:
        file_path (str): Caminho para o arquivo CSV.
    """
    data = pd.read_csv(file_path)
    if {'x', 'y'}.issubset(data.columns):
        plt.figure(figsize=(7, 7))
        plt.axis('equal')
        plt.legend(loc='lower right', fontsize = 'small')
        plt.plot(data['x'], data['y'], label=file_path.split('/')[-1])
        plt.xlabel('x')
        plt.ylabel('y')
        plt.title(f'Gráfico de Posições - {file_path}')
        #plt.legend()
        plt.grid()
        plt.show()
    else:
        print(f"O arquivo {file_path} não contém as colunas necessárias ('x', 'y').")

def plot_multiple_csvs(file_pattern):
    """
    Lê vários arquivos CSV correspondentes a um padrão de nome e plota os dados no mesmo gráfico.

    Args:
        file_pattern (str): Padrão de nomes dos arquivos, e.g., 'posicoesENC*.csv'.
    """
    files = glob.glob(file_pattern)

    if not files:
        print(f"Nenhum arquivo encontrado para o padrão: {file_pattern}")
        return

    #fig, ax = plt.subplots()
    #plt.subplots()
    plt.figure(figsize=(7, 7))
    plt.axis('equal')
    plt.legend(loc='lower right', fontsize = 'small')

    #Lista com as posições finais de cada teste
    posicoes = []
    for file_path in files:
        data = pd.read_csv(file_path)
        # Converter as colunas 'x' e 'y' da última linha em um array NumPy
        posicao = data.iloc[-1][['x', 'y']].values
        posicoes.append(posicao)
        if {'x', 'y'}.issubset(data.columns):
            plt.plot(data['x'], data['y'], label=file_path.split('/')[-1])
        else:
            print(f"O arquivo {file_path} não contém as colunas necessárias ('x', 'y').")

    plt.xlabel('X(m)', fontsize=14)
    plt.ylabel('Y(m)', fontsize=14)
    #ax.set_xlabel("X(metros)")
    #ax.set_ylabel("Y(metros)")
    #plt.title('Odometria - Sentido Anti-Horário')
    plt.title('Odometria - Sentido Horário')
    #ax.set_title("Teste para calibração de odometria - Sentido Horário")
    #plt.legend()
    plt.grid()
    plt.show()
    return posicoes


# Geração de dados fictícios de exemplo (10 medidas de posições finais)
posicoes = np.array([
    [1.2, 0.8],
    [1.5, 1.1],
    [1.3, 1.0],
    [1.4, 0.9],
    [1.6, 1.2],
    [1.7, 1.3],
    [1.8, 1.1],
    [1.5, 1.0],
    [1.4, 0.8],
    [1.6, 1.1]
])

############## ENCODER ####################################
# Exemplos de uso
# Para plotar um único arquivo CSV:
#plot_individual_csv('Anti-Horário/posicoesENC28.csv')
#plot_individual_csv('Horário/posicoesENC0.csv')
#plot_individual_csv('Reta/posicoesENC0.csv'

# Para plotar múltiplos arquivos que seguem o padrão 'posicoesENC*.csv':
#pos, fig, ax = plot_multiple_csvs('Anti-Horário/posicoesENC*.csv')
#posicoes = np.array(pos)
#posicoes = np.array(plot_multiple_csvs('Horário/posicoesENC*.csv'))
#plot_multiple_csvs('Reta/posicoesENC*.csv')

############## IMU ####################################
# Exemplos de uso
# Para plotar um único arquivo CSV:
#plot_individual_csv('IMU/Anti-Horario/posicoesENC-1.csv')
#plot_individual_csv('IMU/Horario/posicoesENC0.csv')
#plot_individual_csv('IMU/Reta/posicoesENC0.csv'

# Para plotar múltiplos arquivos que seguem o padrão 'posicoesENC*.csv':
#plot_multiple_csvs('IMU/Anti-Horario/posicoesENC*.csv')
plot_multiple_csvs('IMU/Horario/posicoesENC*.csv')
#plot_multiple_csvs('IMU/Reta/posicoesENC*.csv')


############## ENCODER CALIBRADO ####################################
# Exemplos de uso
# Para plotar um único arquivo CSV:
#plot_individual_csv('Anti-HorárioCalibrada/posicoesENC28.csv')
#plot_individual_csv('HorárioCalibrada/posicoesENC0.csv')
#plot_individual_csv('RetaCalibrada/posicoesENC0.csv'

# Para plotar múltiplos arquivos que seguem o padrão 'posicoesENC*.csv':
#plot_multiple_csvs('Anti-HorárioCalibrada/posicoesENC*.csv')
#posicoes = np.array(pos)
#posicoes = np.array(plot_multiple_csvs('HorárioCalibrada/posicoesENC*.csv'))
#plot_multiple_csvs('RetaCalibrada/posicoesENC*.csv')


#Plota a elipse de disperção das posições finais de cada teste
#PlotElipse(posicoes, fig, ax)