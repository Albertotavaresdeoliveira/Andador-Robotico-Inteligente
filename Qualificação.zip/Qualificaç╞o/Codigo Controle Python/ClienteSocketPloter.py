# Cliente no computador
# Recebe os dados de posição via socket e plota em tempo real

import socket
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import time

# Configuração do socket
#SERVER_IP = '192.168.0.100'  # Substitua pelo IP da BeagleBone Blue (LARS)
SERVER_IP = '192.168.1.99'  # Substitua pelo IP da BeagleBone Blue (CASA)
SERVER_PORT = 5000           # Porta do servidor

# Conexão ao servidor
client_socket = None
connected = False
while not connected:
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        #client_socket.settimeout(10)  # Timeout de 5 segundos
        client_socket.connect((SERVER_IP, SERVER_PORT))
        print(f"Conectado ao servidor {SERVER_IP}:{SERVER_PORT}")
        connected = True
        print("Conexão bem-sucedida!")
    except (socket.timeout, ConnectionRefusedError) as e:
        print(f"Erro ao conectar: {e}. Tentando novamente em 1 segundo...")
        client_socket.close()
        time.sleep(1)

# Listas para armazenar as posições recebidas
x_data = []
y_data = []

def update(frame):
    global x_data, y_data
    try:
        # Lê os dados enviados pelo servidor
        data = client_socket.recv(1024).decode('utf-8')
        for line in data.splitlines():
            if ',' in line:
                try:
                    x, y = map(float, line.split(','))
                    x_data.append(x)
                    y_data.append(y)

                    # Atualiza o gráfico
                    ax.clear()
                    ax.plot(x_data, y_data, label='Trajetória do robô')
                    ax.set_xlabel('Posição X (m)')
                    ax.set_ylabel('Posição Y (m)')
                    ax.set_title('Posição do Robô em Tempo Real')
                    ax.legend()
                except ValueError:
                    print(f"Dados inválidos recebidos: {line}")
    except socket.error as e:
        print(f"Erro de socket: {e}")

# Configuração do gráfico
fig, ax = plt.subplots(figsize=(8, 8))
# Manter a escala fixa
#plt.axis('scaled')
# Configurar os limites dos eixos
#plt.xlim(-3, 3)  # Limites do eixo X
#plt.ylim(-3, 3)  # Limites do eixo Y (mesmo intervalo para manter a escala fixa)
ani = FuncAnimation(fig, update, interval=100)  # Atualização a cada 100ms

# Exibe o gráfico
try:
    plt.show()
except KeyboardInterrupt:
    client_socket.close()
    print("Encerrando...")
finally:
    client_socket.close()
    print("Conexão com o servidor encerrada.")
